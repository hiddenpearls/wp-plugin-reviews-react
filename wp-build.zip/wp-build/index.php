<?php

/*
Plugin Name: WP Plugin Reviews React
Plugin URI: http://github.com/hiddenpearls/
Description: A react app which shows a list of plugin reviews from wordpress.org
Version: 1.0.0
Author: Muhammad Adnan
Author URI: http://adnan.pk/
*/

/**
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * **********************************************************************
 */


define( 'WP_PLUGIN_REVIEWS_REACT_VERSION' , '1.0.0' );

add_action( 'wp_enqueue_scripts', 'add_script' );

function add_script() {
	wp_enqueue_script( 'wp-plugin-reviews-react-js', plugins_url( 'assets/js/index_bundle.js', __FILE__ ), array(), WP_PLUGIN_REVIEWS_REACT_VERSION, true );
}


add_shortcode( 'wp-plugin-reviews-react', 'react' );


function react( $atts ) {

	$atts = shortcode_atts( array(
		'slug' => 'wp-analytify',
	), $atts );

	return '<div class="app"  data-slug="' . $atts['slug'] . '" ></div>';
}
